package xml;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
/**
 * 使用DOM4J生成一个xml文档
 * @author soft01
 *
 */
public class WriteXmlDemo {
	public static void main(String[] args) {
		List<Emp> list = new ArrayList<Emp>();
		list.add(new Emp(11,"张三",32,"男",5000));
		list.add(new Emp(22,"李四",33,"女",6000));
		list.add(new Emp(33,"王五",34,"男",7000));
		list.add(new Emp(44,"赵六",35,"女",8000));
		/*
		 * 生成XML的大致步骤:
		 * 1:创建一个Document对象,表示一个空白文档
		 * 2:向Doucument中添加根元素
		 * 3:按照XML文档结构从根标签开始逐级添加子标签及对应数据
		 * 4:创建XmlWriter
		 * 5:使用XmlWriter写出Doucument以生成文档
		 */
		try {
			//1
			Document doc = DocumentHelper.createDocument();
			/*
			 * 2 Document提供了添加根元素的方法:
			 *   Element addElement(String name)
			 *   添加后会返回Element根标签实例,
			 *   注意这个方法只能使用一次,因为根标签只有一个
			 */
			Element root = doc.addElement("lsit");
			/*
			 * Element也提供了添加相关信息的方法:
			 * Element addElement(String name) 
			 * 向当前标签中添加给定名字的子标签
			 * 
			 * ELement addText(String name)
			 * 向当前标签中添加指定文本.返回值还是当前标签
			 * 这样做的好处可任意连续操作当前标签
			 */
			for(Emp emp : list) {
				//向根标签添加<emp>子标签
				Element empEle = root.addElement("emp");
				//添加名字
				Element nameEle = empEle.addElement("name");
				nameEle.addText(emp.getName());
				//添加年龄
				Element ageEle = empEle.addElement("age");
				ageEle.addText(emp.getAge()+"");
				//添加性别
				empEle.addElement("gender").addText(emp.getGender());
				//添加工资
				empEle.addElement("salary").addText(emp.getSalary()+"");
				//添加属性
				empEle.addAttribute("id",emp.getId()+"");
			}
			/*
			 * XMLWriter符合java高级流用法.
			 * 它负责将Document对象以XML文档格式进行写出.
			 * 并通过其连接的文件流写入到文件中
			 */
			XMLWriter writer = new XMLWriter(new FileOutputStream("myemp.xml"),OutputFormat.createPrettyPrint());
			//将Document写出以生成XML文档
			writer.write(doc);
			
			System.out.println("写出完毕!");
			
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






