package xml;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * 使用DOM4J解析XML文件
 * @author soft01
 *
 */
public class ParseXmlDemo {
	public static void main(String[] args) {
		/*
		 * 将emplist.xml文件中的所有员工信息读取出来
		 */
		List<Emp> list = new ArrayList<Emp>();
		/*
		 * 使用dom4j解析XML的大致步骤:
		 * 1:创建SAXReader
		 * 2:使用SAXReader读取xml文档并生成Document对象.
		 *   这一步也是dom解析耗时耗资源的地发,因为要将文档所有数据
		 *   读取完毕,并且已一个Document对象形式保存在内存中
		 * 3:通过Document对象获取根元素
		 * 4:按照XML文档结构从根元素开始逐级获取子元素,遍历XML文档数据.
		 */
		try {
			SAXReader reader = new SAXReader();
			Document doc = reader.read(new File("emplist.xml"));
			/*
			 * Document提供了获取根元素的方法:
			 * Element getRootElement()
			 * 
			 * 而Element的每一个实例用于表示当前xml文档
			 * 中的一个元素(一对标签)它提供类获取其表示的
			 * 元素的相关信息的方法:
			 * 
			 * String getName()
			 * 获取当前标签的名字
			 * 
			 * String getText()
			 * 获取当前标签中间的文本
			 * 
			 * Element element(String name)
			 * 获取当前标签下指定名字的子标签
			 * 
			 * List elements()
			 * 获取当前标签下所有子标签
			 * 
			 * List elements(String name)
			 * 获取当前标签下指定名字的所有相同子标签
			 * 
			 * Attribute attribute(String name)
			 * 获取当前标签下指定名字的属性
			 * Attribute的每个实例表示一个属性它有两个常用的方法:
			 * String getName() 获取属性名
			 * String getValue() 获取属性值
			 */
			Element root = doc.getRootElement();  //<list>根标签
			/*
			 * 获取根标签<list>下的所有员工标签<emp>
			 */
			List<Element> empList = root.elements("emp");
			System.out.println("员工数量:"+empList.size());
			System.out.print("分别是:");
			System.err.println("\t ______________________");
//			System.err.println("\t编号 姓名 年龄 性别 工资");
			for(Element empEle : empList) {
				//获取id和name对应的值
				int idValue = Integer.parseInt(empEle.attribute("id").getValue());
				String nameValue = empEle.attributeValue("name");
				//获取age,gender和salary的文本内容
				int age = Integer.parseInt(empEle.element("age").getTextTrim());
				String gender = empEle.elementTextTrim("gender");
				int salary = Integer.parseInt(empEle.elementTextTrim("salary"));
//				System.out.println("\t "+idValue+": "+nameValue+"  "+age+"  "+gender+" "+salary);
				Emp emp = new Emp(idValue,nameValue,age,gender,salary);
				System.out.println("\t"+emp);
				list.add(emp);
			}
			System.out.println("解析完毕!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}










