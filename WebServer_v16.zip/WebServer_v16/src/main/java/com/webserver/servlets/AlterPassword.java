package com.webserver.servlets;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Arrays;

import com.webserver.http.HttpRequest;
import com.webserver.http.HttpResponse;
/**
 * 修改密码
 * @author soft01
 *
 */
public class AlterPassword extends HttpServlet{
	public void service(HttpRequest request,HttpResponse response) {
		String username = request.getParameter("username");
		String oldpwd = request.getParameter("password");
		String newpwd = request.getParameter("new_password");
		try (RandomAccessFile raf = new RandomAccessFile("user.dat","rw")){
			boolean check = false;
			for(int i=0;i<raf.length();i++) {
				//读用用户名
				raf.seek(i*100);
				byte[] data = new byte[32];
				raf.read(data);
				String name = new String(data,"UTF-8").trim();
				if(name.equals(username)) {
					//读原密码
					check = true;
					raf.read(data);
					String oldp = new String(data,"utf-8").trim();
					if(oldp.equals(oldpwd)) {
						//改为新密码
						raf.seek(i*100+32);
						byte[] b = newpwd.getBytes("utf-8");
						b = Arrays.copyOf(b, 32);
						raf.write(b);
						forward("/myweb/alter_pwd_success.html",request,response);
					}else {
						//旧密码输入错误
						forward("/myweb/alter_pwd_fail.html",request,response);
					}
					break;
				}
			}
			if(!check) {
				//查无此人
				forward("/myweb/alter_pwd_nouser",request,response);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}



