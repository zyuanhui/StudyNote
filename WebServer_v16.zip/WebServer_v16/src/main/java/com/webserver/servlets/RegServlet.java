package com.webserver.servlets;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Arrays;

import com.webserver.http.HttpRequest;
import com.webserver.http.HttpResponse;

/**
 * 处理注册业务
 * @author soft01
 *
 */
public class RegServlet extends HttpServlet{
	public void service(HttpRequest request,HttpResponse response) {
		/*
		 * 注册大致流程:
		 * 1:获取用户提交的注册信息
		 * 2:将注册信息写入文件user.dat
		 * 3:响应客户端注册成功的页面
		 */
		System.out.println("开始处理注册业务啦!!");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String nickname = request.getParameter("nickname");
		int age;
		if(request.getParameter("age").matches("\\d+")) {
			age = Integer.parseInt(request.getParameter("age"));
		}else {
			age = 100;
		}
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		System.out.println("nickname:"+nickname);
		System.out.println("age:"+age);
		/*
		 * 每条记录占100字节,其中用户名,密码,昵称为字符串
		 * 各占32字节
		 * 年龄为int值,占2字节.写入到user.dat文件
		 */
		try(RandomAccessFile raf = new RandomAccessFile("user.dat","rw");){
			raf.seek(raf.length());
			byte[] data = username.getBytes("UTF-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			
			data = password.getBytes("UTF-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			
			data = nickname.getBytes("UTF-8");
			data = Arrays.copyOf(data, 32);
			raf.write(data);
			
			raf.writeInt(age);
			System.out.println("注册完毕!");
			//3响应客户端注册成功页面
			forward("/myweb/reg_success.html",request,response);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}






