package com.webserver.http;

public class Demo {
	public static void main(String[] args) {
		String fileName = "11.22.33.logo.png";
		String[] s = fileName.split("\\.");
		System.out.println(s[s.length-1]);
		
		System.out.println(fileName.substring(fileName.lastIndexOf(".")+1));
	}
}
