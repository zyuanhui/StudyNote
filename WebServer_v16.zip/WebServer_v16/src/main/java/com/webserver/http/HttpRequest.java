package com.webserver.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.webserver.core.EmptyRequestException;

/**
 * 请求对象
 * 每个实例表示客户端发送过来的一个具体请求
 * @author soft01
 *
 */
public class HttpRequest {
	/*
	 * 请求行相关信息定义
	 */
	//请求方式
	private String method;
	//请求路径
	private String url;
	//url中的请求部分
	private String requestURI;
	//url中的参数部分
	private String queryString;
	//每个参数
	private Map<String,String> parameters = new HashMap<String,String>();
	
	//协议版本
	private String protocol;
	
	/*
	 * 消息头相关信息定义
	 */
	private Map<String,String> headers = new LinkedHashMap<String,String>();
	
	/*
	 * 消息正文相关信息定义
	 */
	
	//客户端连接相关信息
	private Socket socket;
	private InputStream in;
	
	/**
	 * 初始化请求
	 * @throws EmptyRequestException 
	 */
	public HttpRequest(Socket socket) throws EmptyRequestException{
		try {
			this.socket = socket;
			this.in = socket.getInputStream();
			/*
			 * 解析请求
			 */
			parseRequestLine();  //解析请求行
			parseHeaders();		 //解析消息头
			parseContent();		 //解析消息正文
		} catch (EmptyRequestException e) {
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 解析请求行
	 */
	private void parseRequestLine() throws EmptyRequestException{
		System.out.println("开始解析请求行..");
		try {
			String line = readLine();
			System.out.println("请求行："+line);
			/*
			 * 将请求行进行拆分，每部分设置到对应的属性上。
			 */
			String[] s = line.split(" ");
			if(s.length!=3) {
				//空请求异常
				throw new EmptyRequestException();
			}
			method = s[0];
			url = s[1];
			parseURL();
			protocol = s[2];
			System.out.println("请求方式-method："+method);
			System.out.println("请求路径-url："+url);
			System.out.println("协议版本-protocol："+protocol);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("请求行解析完毕!");
	}
	/**
	 * 进一步解析URL
	 * url有可能会有两种格式:带参数和不带参数
	 * 1.不带参数  如:/myweb/reg.html
	 * 2.带参数  
	 * 如:/myweb/reg?username=zyh&password=123456&nickname=ahui&age=24
	 */
	private void parseURL() {
		/*
		 * 首先判断当前url是否含有参数,判断的依据是看
		 * url是否含有"?",含有则认为这个url是包含参数的,
		 * 否则直接将url赋值给requestURI即可.
		 * 
		 * 若有参数:
		 *  1:将url按照"?"拆分为两部分,第一部分为请求部分,赋值给
		 *  requestURI,第二部分为参数部分,赋值给queryString
		 *  2:再对queryString进一步拆分,先按照"&"拆分出每个
		 *  参数,再将每个参数按照"="拆分为参数名与参数值,并存入
		 *  parameters这个Map中.
		 * 解析过程要注意url的几个特别情况:
		 * 1:url可能含有"?"但是没有参数部分
		 *   如:/myweb/reg?
		 * 2:参数部分有可能只有参数名没有参数值
		 *   如:/myweb/reg?username=&password=123456&nickname=ahui&age=24
		 */
		if(url.matches(".+?.*")) {
			//按照"?"拆分
			String[] u = url.split("\\?");
			requestURI = u[0];
			//判断?后面是否有参数
			if(u.length>1) {
				queryString = u[1];
				parseParameter(queryString);
			}
		}else {
			requestURI = url;
		}
		System.out.println("requestURI:"+requestURI);
		System.out.println("queryString:"+queryString);
		System.out.println("parameters:"+parameters);
	}
	/**
	 * 解析消息头
	 */
	private void parseHeaders() {
		System.out.println("开始解析消息头..");
		try {
			String line = null;
			while(!"".equals(line=readLine())) {
				String[] s = line.split(":\\s");
				headers.put(s[0],s[1]);
			}
			System.out.println("headers:"+headers);
			//
			Set<Entry<String,String>> entrySet = headers.entrySet();
			for(Entry<String,String> e : entrySet) {
				System.out.println("<键>"+e.getKey()+"<值>"+e.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("消息头解析完毕!");
	}
	/**
	 * 解析消息正文
	 */
	private void parseContent() {
		System.out.println("开始解析消息正文..");
		/*
		 * 根据消息头是否含有Content-Length判断该请求是否含有消息正文
		 */
//		Set<String> set = headers.keySet();
//		for(String s : set) {
//			if("Content-Length".equals(s)) {
//			}
//		}
		try {
			if(headers.containsKey("Content-Length")) {
				//含有消息正文
				int length = Integer.parseInt(headers.get("Content-Length"));
				//读取消息正文内容
				byte[] data = new byte[length];
				in.read(data);
				/*
				 * 根据消息头判断消息正文数据类型
				 * Content-Type=application/x-www-form-urlencoded
				 */
				String contentType = headers.get("Content-Type");
				//判断是否为form表单
				if("application/x-www-form-urlencoded".equals(contentType)) {
					/*
					 * 该正文内容相当于原GET请求地址栏中url中"?"右侧的内容
					 */
					String line = new String(data,"ISO8859-1");
					System.out.println("正文内容:"+line);
					parseParameter(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("消息正文解析完毕!");
	}
	/**
	 * 解析参数
	 * 格式:username=zyh&password=1234...
	 * @param line
	 */
	private void parseParameter(String line) {
		/*
		 * 先将参数中
		 */
		try {
			System.out.println("line"+line);
			line = URLDecoder.decode(line,"UTF-8");
			System.out.println("line"+line);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		//按照&拆分出每一个参数
		String[] queryAll = line.split("&");	
		//遍历每个参数进行拆分
		for(String query : queryAll) {
			//再按照"="拆分每个参数
			String[] nameValue = query.split("=");
			//该参数没有值
			if(nameValue.length==1) {
				nameValue[1] = null;
			}
			parameters.put(nameValue[0], nameValue[1]);
		}
	}
	/**
	 * 读取一行字符串，当连续读取CR，LF时停止
	 * 并将之前的内容以一行字符串的形式返回。
	 * @return
	 * @throws IOException
	 */
	private String readLine() throws IOException{
		StringBuilder builder = new StringBuilder();
		int d =-1;
		char c1='a',c2;
		while((d = in.read())!=-1) {
			c2 = (char)d;
			if(c1==HttpContext.CR&&c2==HttpContext.LF) {
				break;
			}
			builder.append(c2);
			c1 = c2;
		}
		return builder.toString().trim();
	}
	public String getMethod() {
		return method;
	}
	public String getUrl() {
		return url;
	}
	public String getProtocol() {
		return protocol;
	}
	public String getHeader(String key) {
		return headers.get(key);
	}
	public String getRequestURI() {
		return requestURI;
	}
	public String getQueryString() {
		return queryString;
	}
	/**
	 * 根据给定的参数名获取对应的参数值
	 * @param name
	 * @return
	 */
	public String getParameter(String name) {
		return parameters.get(name);
	}
}




