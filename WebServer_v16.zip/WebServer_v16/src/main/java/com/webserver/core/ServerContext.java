package com.webserver.core;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/*******************************
 * 服务端相关配置信息
 * @author soft01
 *
 */
public class ServerContext {
	/*
	 * Servlet映射关系
	 * key:请求路径
	 * value:Servlet的名字
	 */
	private static Map<String,String> servletMapping = new HashMap<String,String>();
	static {
		initServletMapping();
	}
	private static void initServletMapping() {
//		servletMapping.put("/myweb/reg", "com.webserver.servlets.RegServlet");
//		servletMapping.put("/myweb/login", "com.webserver.servlets.LoginServlet");
//		servletMapping.put("/myweb/alter_password", "com.webserver.servlets.AlterPassword");
		/*
		 * 加载conf/servlets.xml文件初始化
		 */
		try {
			SAXReader reader = new SAXReader();
			Document doc = reader.read(new File("conf/Servlets.xml"));
			Element root = doc.getRootElement();
			List<Element> list = root.elements();
			for(Element ele : list) {
				String url = ele.attributeValue("url").trim();
				String className = ele.attributeValue("className").trim();
				servletMapping.put(url,className);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static String getServletName(String url) {
		return servletMapping.get(url);
	}
	public static void main(String[] args) {
		System.out.println(getServletName("/myweb/reg"));
	}
}













