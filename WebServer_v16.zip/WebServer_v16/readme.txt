版本3
解析请求：
将客户端发送过来的请求以一个HttpRequest对象的形式保存，
以便于后期处理时可以方便的取到请求中各个信息。

实现：
1：新建一个包com.webserver.http
2：在该报中定义一个类：HttpRequest
3：在该类中定义请求中个部分信息对应的属性
4：定义构造方法用来初始化（解析）请求。


版本4
根据请求将客户端需要的资源相应回去。
1.在项目中新建一个存放“网站资源”的宗目录webapps （application 应用）
  TomCat中也是这样做的，每个网站被称为一个webapp，他包含该网站的资源
  还包含处理业务的java程序。而每个webapp都以一个子目录的形式保存在webapps中
  被TomCat统一管理。
2.在webapps下建立一个子目录：myweb，作为我们测试使用的web应用。
3.在myweb目录下新建第一个页面：index.html 
4.在ClientHandler中根据request获取客户端请求的资源路径，然后对应的去
  webapps下找该资源并做好分支判断。 
  
  
版本5
重构项目：
将ClientHandler中响应客户端的操作进行重构。
设计一个类：HttpResponse,
用它的每一个实例表示服务端发送给客户端的一个具体响应内容。
1：在http包中添加类：HttpResponse
2：在HttpResponse类中定义方法：flush,用来将当前响应发送给客户端。
   flush需要做的三件事：
   1：发送状态行
   2：发送响应头
   3：发送响应正文
3：将ClientHandler中响应客户端的操作移动到HttpResponse对应方法中
4：在ClientHandler中实例化HttpResponse，并设置要响应的内容后，
   调用flush方法响应客户端。


版本6
添加响应404页面的操作
当客户端请求的资源不存在时,应当响应给客户端404页面.并且状态代码与描述也要对应.
1:在HttpResponse中定义属性:int statusCode表示状态代
  String statusReason表示状态描述
  他们的默认值分别为200,"OK"
  这样做的好处在于正常响应时可以不设置这两个值.
  提供对应的get,set方法.
2:修改sendStatusLine方法,将发送状态行的代码改为发送对应属性statusCode,statusReason
3:在http包中新建一个类:HttpContext
  使用这个类来定义相关Http协议中的内容.
  定义一个静态属性:status_code_reason_mapping
  他是一个Map类型的,其中key存放状态代码,value存放对应的状态描述.
  这样便于我们将来根基状态代码直接获取到对应的描述信息.
4:在HttpResponse的设置状态代码的方法中添加根据状态代码去HttpContext中获取
  对应状态描述并设置到状态描述属性上.
  这样的好处在于,将来外面对respone设置状态代码时就无需再单独设置状态描述了.
5:在webapps目录下新建一个目录root,在里面创建页面:404.html
  这个页面是一个公共页面,无论请求我们哪个应用中的资源,只要不存在都会响应这个页面.
6:在ClientHandler处理请求的分支中,如果资源没有找到,则设置response的状态代码为404
  并且将webapps/root/404.html页面设置好,这样就会将该页面响应给客户端了  
  
版本7
处理空请求
HTTP协议允许客户端发送空请求.就是客户端与服务端连接后,实际没有发送任何内容,但是我们
现在的处理是要解析请求,这会导致HttpRequest解析异常.
对此,我们解析请求时如果发现空请求,就会将异常抛给ClientHandler,并且ClientHandler
在接收到这个异常后就不再做后续处理,直接与服务端断开连接即可.
1:在core包中添加一个自定义异常:
  EmptyRequestException  空请求异常
2:在HttpRequest解析请求行时若发现是空请求则实例化空请求异常并将其抛给构造方法,
  再经构造方法继续抛给ClientHandler.
3:ClientHandler的run方法中添加一个空请求的捕获操作.以达到当实例化HttpRequest出现
  空请求后跳过其他所有操作的目的.
  
版本8
修改响应,使得响应中的响应头变为可以进行设置的这样才能保证根据实际情况响应不同的内容.
1:在HttpResponse中定义一个属性:Map headers其中key保存响应头的名字,value保存对应的值
2:修改sendHeaders方法
4:由于一个响应中包含响应正文时一定会在响应头中包含Content-Type和Content-Length
  对此我们直接在HttpResponse的setEntity方法中添加代码根据给定的文件自动设置这两个头.
  这样免去；外界在设置响应正文后还要额外添加这两个头的麻烦.
5:由于不同的文件对应的Content-Type值是不同的,并且w3c中都有规定,对此我们可以在HttpContext
  中再定义一个Map,其中key保存文件的后缀,value保存其介质类型.这样将来我们可以根据文件的后缀
  来获取到对应的值设置到响应头中.

版本9
重构代码
1:HttpResponse中发送状态行与响应头都使用了相同的代码,应当复用.
  对此我们在HttpResponse中定义一个方法:println来复用这个功能.
2:在HttpContext中将CR,LF定义为常量,这样在HttpRequest和HttpResponse中都去引用.

版本10
利用Tomcat安装目录下conf/web.xml文件，将所有的介质类型
解析出来并使用。
1:在当前项目目录下新建一个目录:conf
2:将tomcat中web.xml文件拷贝到该目录
3:重构HttpContext类中initMimeMapping方法，通过解析web.xml
    来初始化Content-Type头所对应的值。  

版本11
完成注册业务
我们日常上网常见的操作如:登录，注册等，都是在页面中填写
好数据后，浏览器提交一个表单给服务端。而提交表单有两种
形式:GET,POST
GET形式成为地址栏形式提交，数据会包含在地址栏中“?”右侧
POST形式提交数据，数据会被包含在请求的消息正文中。

对此，服务端在解析请求时，要考虑用户可能会传递数据的情况
并对数据进行解析，以便在处理业务的过程中获取这些数据。

1:在webapps/myweb/下新建一个注册页面:reg.html
    在该页面中了解<form>表单的应用。

2:重构HttpRequest解析操作，先完成GET形式提交数据的解析。
  2.1:定义三个属性:requestURI,queryString,parameters
  2.2:定义一个解析url内容的方法:parseUrl
  2.3:在parseRequestLine方法中，当解析出来url后调用
      parseUrl这个方法对url进一步解析.  
          将请求部分与参数部分进行解析并设置到对应的这三个
          属性上。

3:修改ClientHandler处理请求的逻辑，从原来直接通过请求对象
    根据url进行判断，改进为根据requestURI判断请求内容。并
    进行处理请求的操作。   
5:在webapps/myweb目录中添加注册成功页面:
  reg_success.html
6:完成RegServlet的service方法,在该方法中首先获取用户提交的
  注册信息,并写入到user.dat文件之后设置response响应注册成功页面.

版本12
完成登录业务操作
用户打开登录页面,输入登录信息后点击登录按钮,服务端在接收到这些
数据后比对user.dat文件中所有的注册信息,若有与之匹配的记录则响应登录
成功页面,否则响应登录失败页面.
实现步骤:
1:在webapps/myweb中新建三个页面:
  login.html登录页面
  其中form表单action="login",需要两个输入框:用户及密码
  login_success.html 登录成功提示页面
  login_fail.html 登录失败提示页面
2:在servlets包中添加LoginServlet并定义好对应的service方法
  2.1:通过request获取用户名及密码
  2.2:使用RandomAccessFile读取user.dat文件,读取每条记录的
      用户名,密码,若匹配上则设置response响应登录成功页面
      若最终没有一条记录匹配或对应用户名的密码不对时设置response
      响应登录失败页面.
3:在ClientHandler判断请求是否为注册业务之下再添加一个分支,判断
  请求是否为登录.而登录的请求路径应该为:/myweb/login
  如果该请求时登录业务,则实例化LoginServlet并调用其service方法
  处理登录操作.

版本13  修改密码

版本14
1:重构代码
在servlets包中定义一个超类:HttpServlet,并且定义抽象方法:sevices
然后要求所有的Servlet都继承该类.
将响应页面的逻辑提成一个方法,将相同部分重用.
/*请求方式常见的有两种:
GET:地址栏请求，用户若传递数据则是直接拼在资源路径中
POST:将用户传递的数据包含在消息正文中传递*/
2.使服务端支持POST请求
页面上form表单提交的数据如果含有用户隐私信息或者上传附件时,那么提交形式
就不能使用GET,而应当使用POST请求.
POST请求会将form表单中的数据包含在请求的消息正文中,因此我们要解析请求中
的消息正文部分.
以登录为例:
1.修改登录页面中form表单提交形式为:POST
2.当form表单以POST形式提交时,该请求的消息头中会出现Content-Length
与Content-Type,我们可以根据是否含有这两个头来判断是否有消息正文.
例:Content-Type=application/x-www-form-urlencoded
完成HttpRequest的parseContent方法,解析正文

3.解决浏览器通过GET或POST形式请求传递数据的中文问题。
HTTP协议要求，请求行，消息头这些部分出现的字符对应的
字符集只能是ISO8859-1。而该字符集是不支持中文的。对此
我们不能直接传递中文。

浏览器的做法是将中文按照对应字符集(通常是UTF-8)将该字符
转换为一组字节，然后每个字节以2位16进制的字符串形式表示，
并在前面添加一个%。

java中提供了一个解析URL中%XX内容的API:URLDecoder

在HttpRequest中，进一步解析URL的方法:parseURL中使用
URLDecodeint br对url解码，从而得到正确的字符。

例如:
myweb/login?username=范传奇

实际上发送的是:
myweb/login?username=%E8%8C%83%E4%BC%A0%E5%A5%87

"范"用UTF-8编码转换后的三个字节输出的整数对应为:
-24, -116, -125

11101000  -24    %E8
10001100  -116   %8C
10000011  -125   %83

2进制     10进制        16进制
0000    0         0
0001    1         1 
0010    2         2
0011	  3         3
0100	  4         4
0101    5         5
0110    6         6
0111    7         7
1000    8         8

版本15
利用反射机制
加载Servlet来解决添加不同业务时每次对ClientHandler的修改.
思路:
我们设置一个Map,key保存请求路径,value保存对应的Servlet的名字.
key作为路径,利用反射机制加载这个类并实例化,然后调用其service方法
进行处理.
而这个Map的数据可以来源与一个XML文件,从而做到请求与对应Servlet可以
进行配置.

版本16
重构WebServer类,使用线程池来管理处理客户端请求的ClientHandler.




























  
  
  
  
  
  