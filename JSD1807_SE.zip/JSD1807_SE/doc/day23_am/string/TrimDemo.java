package string;
/**
 * String trim()
 * ȥ��һ���ַ������ߵĿհ��ַ�
 * 
 * @author adminitartor
 *
 */
public class TrimDemo {
	public static void main(String[] args) {
		String string = "   hello			";
		System.out.println(string);
		
		String trim = string.trim();
		System.out.println(trim);
	}
}





