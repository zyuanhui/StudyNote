package reflect;

public class TestCase {
	
	public void testHello(){
		System.out.println("Hello");
	}

	public void testWho(){
		System.out.println("Who");
	}

	public void demo() {
		System.out.println("demo");
	}
	
}
