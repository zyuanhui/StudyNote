package reflect;

public class Goo {
	int b;
	
	public Goo(int b) {
		this.b = b;
	}
}
