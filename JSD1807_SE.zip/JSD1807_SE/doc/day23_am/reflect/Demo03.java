package reflect;

public class Demo03 {

	public static void main(String[] args) {
		Foo foo = new Foo();
		//foo.
	}

}
