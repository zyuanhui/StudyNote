package reflect;

public class Xoo {
	
	@Override  //ע��
	public String toString() {
		return super.toString();
	}
}
