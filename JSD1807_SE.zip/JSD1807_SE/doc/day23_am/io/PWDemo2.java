package io;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

/**
 * ����������ʹ��PW
 * 
 * @author adminitartor
 *
 */
public class Base {
	int w, x, y, z;

	public Base(int a, int b) { x=a; y=b; }

public Base(int a, int b, int c, int d) { // assignment x=a, y=b w=d; z=c; } }
