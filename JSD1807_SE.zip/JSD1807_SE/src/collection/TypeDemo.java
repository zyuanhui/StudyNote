package collection;

public class TypeDemo {
	public static void main(String[] args) {
		Location<Double,Integer> l1 = new Location<Double,Integer>(1.0,2);
		l1.setX(2.0);
		double x1 = l1.getX();
		System.out.println("l1:"+l1);
		System.out.println("x1:"+x1+"\n");
		
		Location<String,Character> l2 = new Location<String,Character>("���",'��');
		l2.setX("���Ǻ�");
		String x2 = l2.getX();
		System.out.println("l2:"+l2);
		System.out.println("x2:"+x2);
	}
}
