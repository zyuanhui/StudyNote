package lambda;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JDK8֮�󼯺Ϻ�Map��֧��foreach
 * @author soft01
 *
 */
public class LambdaDemo3 {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("һ");
		list.add("һ��");
		list.add("һ����");
		list.add("һ������");
		list.add("һ��������");
		for(String str : list) {
			System.out.println(str);
		}
		
		list.forEach((str)->System.out.println(str));
		list.forEach(System.out::println); 
		
		Map<String,Integer> map = new HashMap<String,Integer>();
		map.put("����", 99);
		map.put("��ѧ", 88);
		map.put("Ӣ��", 77);
		map.forEach((k,v)->System.out.println(k+":"+v));
	}
}




