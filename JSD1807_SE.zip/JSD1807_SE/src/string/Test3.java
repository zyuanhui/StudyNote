package string;
/**
 * ��г����
 * @author ta
 *
 */
public class Test3 {
	public static void main(String[] args) {
		String regex = "(wqnmlgdsb|mmp|nc|mdzz|cnm|djb)";
		String message = "wqnmlgdsb!����ô��ônc!cnm,���djb!";
//		message = message.replaceAll(regex, "***");
		message = message.replaceAll(regex, ".....");
		System.out.println(message);
	}
}








