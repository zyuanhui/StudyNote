package string;
/**
 * String trim()
 * ȥ��һ���ַ������ߵĿհ��ַ�
 * @author ta
 *
 */
public class TrimDemo {
	public static void main(String[] args) {
		String str = "  hello			";
		System.out.println(str);
		String trim = str.trim();
		System.out.println(trim);
	}
}



