package string;

import java.util.Date;

/**
 * ͼƬ������
 * @author ta
 *
 */
public class Test2 {
	public static void main(String[] args) {
		String imageName = "abc.jpg";
		imageName = imageRename(imageName);
		System.out.println(imageName);
	}
	
	public static String imageRename(String imageName) {
		//����"."���
		String[] data = imageName.split("\\.");
		imageName 
			= System.currentTimeMillis()+"."+data[1];
		return imageName;
	}
}




