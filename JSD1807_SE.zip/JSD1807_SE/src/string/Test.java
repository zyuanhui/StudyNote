package string;
/**
 * ��ɷ�������ȡ������ַ�е�����
 * @author ta
 *
 */
public class Test {
	public static void main(String[] args) {
		String url = "www.sohu.com";
		String name = getHostName(url);
		System.out.println(name);//sohu
		
		url = "http://www.tedu.com.cn";
		name = getHostName(url);
		System.out.println(name);//tedu
	}
	public static String getHostName(String url) {
		int start = url.indexOf(".")+1;
		int end = url.indexOf(".",start);
		return url.substring(start, end);
	}
	
}




