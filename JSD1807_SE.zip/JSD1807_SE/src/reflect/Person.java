package reflect;
/**
 * ���Է��书�ܵ���
 * @author soft01
 *
 */
public class Person {
	public Person() {
	}
	public Person(int m,int n) {
	}
	public void sayHello() {
		System.out.println("hello!");
	}
	public void sayHello(String name) {
		System.out.println("hello!"+name);
	}
	public void sayHello(String name,int week) {
		System.out.println("hello!"+name+",��������"+week+"��?");
	}
	public void sayHi() {
		System.out.println("hi!");
	}
}
