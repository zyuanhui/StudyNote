package reflect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

/*
 * �����вη���
 */
public class ReflectDemo4 {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
//		Person p = new Person();
//		p.sayHello("С��");
//		p.sayHello("С��",3);
		Scanner s = new Scanner(System.in);
		System.out.println("����������:");
		Class cls = Class.forName(s.nextLine());
		Object o = cls.newInstance();
		System.out.println("�����뷽����:");
		Method method = cls.getMethod(s.nextLine(),String.class);
		System.out.println("����������:");
		method.invoke(o,s.nextLine());
		
		Method method2 = cls.getMethod("sayHello",String.class,int.class);
		method2.invoke(o,"С��",5);
	}
}




