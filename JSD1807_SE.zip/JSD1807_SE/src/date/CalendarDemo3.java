package date;

import java.util.Calendar;

/**
 * void set(int field,int value)
 * ��ָ����ʱ���������ָ����ֵ
 * @author soft01
 *
 */
public class CalendarDemo3 {
	public static void main(String[] args) {
		Calendar c = Calendar.getInstance();
		/*
		 * ��ʾ2008-08-08 20:08:08
		 */
		c.set(Calendar.YEAR, 2008);
		c.set(Calendar.MONTH, 7);
		c.set(Calendar.DAY_OF_MONTH, 8);
		c.set(Calendar.HOUR_OF_DAY, 20);
		c.set(Calendar.MINUTE, 8);
		c.set(Calendar.SECOND, 8);
		c.set(Calendar.DAY_OF_WEEK, 1);
		
		c.set(2019, 8, 9, 9, 9, 9);
		
		System.out.println(c.getTime());
	}
}











