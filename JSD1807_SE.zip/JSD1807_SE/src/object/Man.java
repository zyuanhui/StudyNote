package object;
/**
 * ���������˸�Ů����
 * @version 1.0
 */
public class Man extends SuperMan{
	private static String name;
	private static double salary;
	public Man(String name) {
		this.name = name;
		playGame();
	}
	public static void main(String[] args) {
		Man superMan = new Boy("ZYH");
		Girl smartGirl = null;
		try {
			smartGirl = new Girl("LYL");
			gameover();
			work();
			salary = 5000;
		} catch (Exception e) {
			salary-=smartGirl.eat();
			salary-=smartGirl.buy();
		} finally{
			if(salary>0) {
				salary-=superMan.giveMoney();
			}
		}
	}
	public void playGame() {
		
	}
	static void work() {
		
	}
	static void gameover() {
		
	}
	private  int giveMoney() {
		return 100;
	}
}

class SuperMan{
	
}
class Boy extends Man{
	public Boy(String name) {
		super(name);
	}
}
class Girl{
	Girl(String name){
		
	}
	double eat() {
		return 100;
	}
	double buy() {
		return 200;
	}
}




