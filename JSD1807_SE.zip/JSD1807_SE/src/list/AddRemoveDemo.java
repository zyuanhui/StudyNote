package list;

import java.util.ArrayList;
import java.util.List;

/**
 * List������add��remove����
 */
public class AddRemoveDemo {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		list.add("five");
		System.out.println(list);
		/*
		 * void add(int index,Element e)
		 * ��ָ��Ԫ�ز��뵽ָ��λ��
		 */
		list.add(1,"2");
		System.out.println(list);
		String old = list.remove(2);
		System.out.println(list);
		System.out.println(old);
		list.remove("five");
		System.out.println(list);
	}
}







